LD_LIBRARY_PATH=lib/ ./bedrock_server

ln libstdc++.so.6.0.22 libstdc++.so.6
rm -f csh.sh